const PRODUCTS = [
    {
        id: 1,
        name: "Luxury Chocolate Box",
        price: 850,
        category: "Sweet Treats",
        image: "assets/products/luxury-chocolate-box.svg",
        description: "A premium chocolate gift box, perfect for birthdays, anniversaries and special surprises.",
        badge: "Best Seller"
    },
    {
        id: 2,
        name: "Premium Perfume Box",
        price: 1450,
        category: "Luxury Gifts",
        image: "assets/products/premium-perfume-box.svg",
        description: "A classy perfume gift set with a premium presentation for a sophisticated surprise.",
        badge: "New"
    },
    {
        id: 3,
        name: "Birthday Gift Box",
        price: 1200,
        category: "Birthday",
        image: "assets/products/birthday-gift-box.svg",
        description: "A cheerful birthday gift box with an elegant presentation, ready for a special celebration.",
        badge: "Popular"
    },
    {
        id: 4,
        name: "Flower & Chocolate Box",
        price: 1100,
        category: "Flowers",
        image: "assets/products/flower-chocolate-box.svg",
        description: "A beautiful combination of flowers and chocolates arranged as an elegant gift.",
        badge: "Trending"
    },
    {
        id: 5,
        name: "Self-Care Gift Hamper",
        price: 1350,
        category: "Gift Hampers",
        image: "assets/products/self-care-hamper.svg",
        description: "A relaxing self-care hamper with a candle, beauty-style bottles and small treats.",
        badge: "Featured"
    },
    {
        id: 6,
        name: "Anniversary Gift Box",
        price: 1600,
        category: "Anniversary",
        image: "assets/products/anniversary-gift-box.svg",
        description: "An elegant anniversary box designed with a romantic premium presentation.",
        badge: "Premium"
    },
    {
        id: 7,
        name: "Sweet Treats Mini Box",
        price: 650,
        category: "Sweet Treats",
        image: "assets/products/sweet-treats-mini.svg",
        description: "A compact assorted sweets box for a simple surprise or casual celebration.",
        badge: "Mini"
    },
    {
        id: 8,
        name: "Churi Gift Box",
        price: 950,
        category: "Luxury Gifts",
        image: "assets/products/churi-gift-box.svg",
        description: "A decorative traditional-inspired gift box featuring colorful bangles.",
        badge: "Special"
    }
];
